These examples are free to use as a base for your project!

Do check the Credits+License.txt files in each example folder to know what you can use and to what extent!

Note: Canvas components and other assets are broken in Unity 2018