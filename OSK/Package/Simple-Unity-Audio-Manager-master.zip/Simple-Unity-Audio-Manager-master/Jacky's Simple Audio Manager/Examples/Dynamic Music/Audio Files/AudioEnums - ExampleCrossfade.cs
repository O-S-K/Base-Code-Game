namespace JSAM {
    public enum SoundsExampleCrossfade{
    }
    public enum MusicExampleCrossfade{
        Menu,
        MenuPitched
    }
}
