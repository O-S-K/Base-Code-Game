namespace JSAM {
    public enum SoundsLoopPointExample{
    }
    public enum MusicLoopPointExample{
        IntroLoop
    }
}
