namespace JSAM {
    public enum SoundsExample2D{
        BulletHit,
        Shooting
    }
    public enum MusicExample2D{
        MainTheme,
        MainThemeCombined,
        SideTheme
    }
}
