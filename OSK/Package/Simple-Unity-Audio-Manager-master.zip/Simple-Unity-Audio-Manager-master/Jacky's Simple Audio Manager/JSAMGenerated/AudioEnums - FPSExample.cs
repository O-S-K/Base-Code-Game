    public enum FPSExampleSounds {
        AKChamber,
        AKDryFire,
        AKMagGrab,
        AKMagInsert,
        AKMagRemove,
        AKMagTap,
        Gunshot,
        AbstractPop,
        Crouch,
        Running,
        Walk,
        AKEquip
    }
    public enum FPSExampleMusic {
        BGM
    }
