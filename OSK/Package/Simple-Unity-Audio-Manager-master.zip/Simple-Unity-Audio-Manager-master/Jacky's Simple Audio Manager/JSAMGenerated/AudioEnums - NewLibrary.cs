    public enum NewLibrarySounds {
        SpatialSound
    }
    public enum NewLibraryMusic {
    }
