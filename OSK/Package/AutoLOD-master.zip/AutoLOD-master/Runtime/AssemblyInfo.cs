﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.AutoLOD.Editor")]