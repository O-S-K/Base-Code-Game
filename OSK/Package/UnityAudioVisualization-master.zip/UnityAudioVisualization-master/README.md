# Unity Audio Visualization

<img src='/Images/PREVIEW01.gif'/>

This project is a number of audio visualization experiments using Unity3d.
Based on tutorial series by [Peer Play](https://www.youtube.com/watch?v=5pmoP1ZOoNs&list=PL3POsQzaCw53p2tA6AWf7_AWgplskR0Vo).

Refactored and added functionality.

This is work in progress.